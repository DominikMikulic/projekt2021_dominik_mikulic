Upute za pokretanje projekta
imate i video objašnjenje pa možete paralelno pratiti obje varijante
1.Kako bi pokrenuli projekt morate instalirati XAMPP
preuzmite ga sa 
https://www.apachefriends.org/download.html
2.1. Pokrenite xampp control panel
2. Kliknite na Apache Start
3. Pronađite gdje se nalazi folder gdje je instaliran xampp (defaul je C:\xampp)
4. Otvorite "xampp" folder i unutar njega otvorite "htdocs" folder (C:\xampp\htdocs)
5. Unutar "htdocs" foldera kopirajte sav sadržaj koji ste preuzeli, unzipajte ga prije (na datoteku koju ste preuzeli projekt2021)
6. Nakon toga otvorite web pretraživač i u adresnu traku unesite https://localhost/projekt2021/projekt2021.php
7. Ako imate bilo kakvo pitanje pošaljite poruku na dmikulic@tvz.hr

